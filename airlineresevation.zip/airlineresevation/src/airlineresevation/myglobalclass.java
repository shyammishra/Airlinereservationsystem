

package airlineresevation;


public class myglobalclass {
    static String uname;
    static String pwd;
}
